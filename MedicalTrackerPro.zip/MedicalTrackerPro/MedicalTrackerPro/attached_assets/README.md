# NetSecurePro Runner Image

Cette image Docker permet de déployer un runner GitHub Actions auto-hébergé basé sur Ubuntu 22.04.

## Instructions

1. Générez un token d’inscription dans votre dépôt GitHub.
2. Lancez le conteneur Docker avec la variable RUNNER_TOKEN.