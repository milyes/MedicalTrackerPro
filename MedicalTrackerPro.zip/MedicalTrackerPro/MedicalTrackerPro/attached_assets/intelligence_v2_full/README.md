
# IA2_intelligence_v2 - APK Flutter WebView

Cette application Android utilise Flutter WebView pour afficher une interface IA locale (offline) depuis `index.html`.

## Contenu
- WebView avec JWT + API IA intégrée (Flask)
- Splash personnalisé possible
- Compatible avec Termux, GitHub Pages, ou hébergement Flask local

## Structure
- assets/index.html : Interface IA WebView
- Intégration recommandée avec backend Flask (`app.py`)
