
# aiterminal.py

import subprocess
import platform
import psutil
import time
from datetime import datetime
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.live import Live
from rich.text import Text

console = Console()

def scan_wifi():
    console.print("[cyan]Scanning Wi-Fi networks...[/cyan]")
    try:
        result = subprocess.check_output(["nmcli", "-t", "-f", "SSID", "dev", "wifi"]).decode().splitlines()
        networks = [ssid for ssid in result if ssid]
        return networks
    except Exception as e:
        return [f"Error: {e}"]

def system_logs():
    logs = []
    logs.append(f"[{datetime.now().strftime('%H:%M:%S')}] SYSTEM LOG: Process Started")
    cpu_usage = psutil.cpu_percent(interval=1)
    if cpu_usage > 80:
        logs.append(f"[{datetime.now().strftime('%H:%M:%S')}] ALERT - High CPU Usage: {cpu_usage}%")
    else:
        logs.append(f"[{datetime.now().strftime('%H:%M:%S')}] CPU Usage: {cpu_usage}%")
    return logs

def show_dashboard():
    with Live(refresh_per_second=4) as live:
        while True:
            table = Table(title="AITERMINAL - Status Monitor", style="bold cyan")
            table.add_column("Time", justify="center")
            table.add_column("System Log", justify="left")

            logs = system_logs()
            for log in logs:
                table.add_row(datetime.now().strftime("%H:%M:%S"), log)

            networks = scan_wifi()
            net_panel = Panel("\n".join(networks) if networks else "No Wi-Fi networks found", title="Wi-Fi Networks")

            suggestion = Panel(Text("> automate tasks", style="bold green"), title="Suggestion IA")

            layout = Table.grid(expand=True)
            layout.add_row(table)
            layout.add_row(net_panel)
            layout.add_row(suggestion)

            live.update(layout)
            time.sleep(5)

if __name__ == "__main__":
    console.print("[bold magenta]AITERMINAL[/bold magenta] - Initializing...\n")
    time.sleep(1)
    show_dashboard()
