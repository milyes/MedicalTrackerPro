
import 'package:flutter/material.dart';
import 'screens/dashboard.dart';

void main() {
  runApp(AIMEDIXALApp());
}

class AIMEDIXALApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AIMEDIXAL',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: DashboardScreen(),
    );
  }
}
