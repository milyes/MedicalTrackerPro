#!/bin/bash
./config.sh --url https://github.com/TON_ORGANISATION --token $RUNNER_TOKEN --unattended --name netsecurepro-runner
./run.sh